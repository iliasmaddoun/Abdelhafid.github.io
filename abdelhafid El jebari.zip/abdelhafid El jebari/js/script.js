/* ============================== typing animation ============================ */
var typed = new Typed(".typing",{
    strings:["","Automatisierungstechniker","Mechatroniker","Fachkundige Wartung"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})